import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.*;
import java.io.FileNotFoundException;
import java.io.IOException;

class Main {

    public static void main(String[] args) {
        try {
            // read data
            File fakeDataFile = new File(args[0]);
            BufferedReader reader = new BufferedReader(new FileReader(fakeDataFile));

            String line = reader.readLine();
            int monitorPeriod = Integer.parseInt(line);

            Patient patient = null;
            List<Patient> patients = new ArrayList<>();
            while ((line = reader.readLine()) != null) {
                String[] arrOfStr = line.split(" ");
                if (Objects.equals(arrOfStr[0], "patient")) {
                    String name = arrOfStr[1];
                    int period = Integer.parseInt(arrOfStr[2]);
                    patient = new Patient(name, period);
                    patients.add(patient);
                } else {
                    String category = arrOfStr[0];
                    String deviceName = arrOfStr[1];
                    String factorDataFileName = arrOfStr[2];
                    int lowerbound = Integer.parseInt(arrOfStr[3]);
                    int upperbound = Integer.parseInt(arrOfStr[4]);
                    Device device = new Device(category, deviceName, "../Testcase/" + factorDataFileName, lowerbound,
                            upperbound);
                    patient.addDevice(device);
                }
            }

            // start monitoring
            monitoring(patients, monitorPeriod);

            // print database
            for (Patient p : patients) {
                System.out.println("patient " + p.getName());
                for (Device d : p.getDevices()) {
                    System.out.println(d.getCategory() + " " + d.getName());
                    for (String s : d.getDatabase()) {
                        System.out.println(s);
                    }
                }
            }

            reader.close();

        } catch (FileNotFoundException e) {
            System.out.println("File not found.");
        } catch (IOException e) {
            System.out.println("File read error.");
        }
    }

    public static void monitoring(List<Patient> patients, int monitorPeriod) {
        for (int milisecond = 0; milisecond <= monitorPeriod; ++milisecond) {
            for (Patient p : patients) {
                if (milisecond % p.getPeriod() == 0) {
                    for (Device d : p.getDevices()) {
                        float factor = d.readFactor(milisecond);
                        if (factor == -1) {
                            System.out.println("[" + milisecond + "] " + d.getName() + " fails");
                        } else if (factor != -1 && factor != 0) {
                            System.out.print("[" + milisecond + "] " + p.getName() + " is in danger! ");
                            System.out.println("Cause: " + d.getName() + " " + (float) factor);
                        }
                    }
                }
            }
        }
    }
}
