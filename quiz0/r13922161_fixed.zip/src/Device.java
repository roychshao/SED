import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;

class Device {
    private String category;
    private String name;
    private String factorDataFileName;
    private int safeRangeLowerBound;
    private int safeRangeUpperBound;
    private List<Float> factors = new ArrayList<>();
    private int factorPtr = 0;
    private List<String> database = new ArrayList<>();

    public Device(String category, String name, String f, int l, int u) {
        this.category = category;
        this.name = name;
        this.factorDataFileName = f;
        this.safeRangeLowerBound = l;
        this.safeRangeUpperBound = u;
    }

    public String getCategory() {
        return category;
    }

    public String getName() {
        return name;
    }

    public String getFactorDataFileName() {
        return factorDataFileName;
    }

    public int getSafeRangeLowerBound() {
        return safeRangeLowerBound;
    }

    public int getSafeRangeUpperBound() {
        return safeRangeUpperBound;
    }

    public float readFactor(int milisecond) {
        if (factors.size() == 0) {
            readFactors();
            float factor = factors.get(factorPtr);
            String dataItem = "[" + milisecond + "] " + String.valueOf(factor);
            addDatabase(dataItem);

            factorPtr++;
            if (factor == -1) {
                return -1;
            } else if (factor >= safeRangeLowerBound && factor <= safeRangeUpperBound) {
                return 0;
            } else {
                return factor;
            }
        }

        if (factorPtr >= factors.size()) {
            String dataItem = "[" + milisecond + "] " + String.valueOf(-1.0);
            addDatabase(dataItem);
            return -1;
        }

        float factor = factors.get(factorPtr);
        String dataItem = "[" + milisecond + "] " + String.valueOf(factor);
        addDatabase(dataItem);
        factorPtr++;
        if (factor == -1) {
            return -1;
        } else if (factor >= safeRangeLowerBound && factor <= safeRangeUpperBound) {
            return 0;
        } else {
            return factor;
        }
    }

    public void readFactors() {
        File factorFile = new File(factorDataFileName);
        try (BufferedReader reader = new BufferedReader(new FileReader(factorFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                factors.add(Float.parseFloat(line));
            }
        } catch (FileNotFoundException e) {
            System.out.println("File not found");
        } catch (IOException e) {
            System.out.println("Read error");
        }
    }

    public void addDatabase(String s) {
        database.add(s);
    }

    public List<String> getDatabase() {
        return database;
    }
}
